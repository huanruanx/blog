HuanRuan Blog 1.0
===============

> 运行环境要求PHP7.2+，兼容PHP8.1

## 主要新特性

* 框架开发让维护更简单
* 光年后台模板更简洁

## 开源地址:white_check_mark: 
~~~
https://github.com/huanruanx/blog
~~~

## 安装
下载包
~~~
git clone https://github.com/huanruanx/blog.git
~~~

如果需要更新框架使用
~~~
composer update topthink/framework
~~~

## 版权信息

HuanRuan Blog 遵循Apache2开源协议发布，并提供免费使用。
本项目包含的第三方源码和二进制文件之版权信息另行标注。
版权所有Copyright © 2022 by HuanRuan Blog
All rights reserved。

## 其他说明:loudspeaker:

本项目采用大量的开源代码，包括ThinkPHP，光年后台模板等等。 
部分代码可能署名已被某些前辈去掉，我也没来得及去查找具体的作者，
如果有需要修改的地方，可以与我取得联系，love@yyyyyyy.ml。 
在此，对所有用到的开源代码作者表示由衷的感谢。