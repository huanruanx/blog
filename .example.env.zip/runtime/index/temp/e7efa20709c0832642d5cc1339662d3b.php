<?php /*a:1:{s:52:"E:\Web\blog\app\index\view\template\index\index.html";i:1669334964;}*/ ?>
123