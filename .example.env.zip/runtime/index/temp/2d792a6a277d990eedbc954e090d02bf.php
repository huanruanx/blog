<?php /*a:3:{s:45:"E:\Web\blog\app\index\view\dispaly\index.html";i:1670136319;s:45:"E:\Web\blog\app\index\view\public\header.html";i:1669528487;s:45:"E:\Web\blog\app\index\view\public\footer.html";i:1669893155;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-22 19:40:07
 * @LastEditTime : 2022-12-04 14:45:11
 * @FilePath     : \blog\app\index\view\dispaly\index.html
-->
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-22 19:20:12
 * @LastEditTime : 2022-11-27 13:54:00
 * @FilePath     : \blog\app\index\view\public\header.html
-->

<!DOCTYPE HTML>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo htmlentities($middle['system']['webname']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="yinqi" />
    <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/materialdesignicons.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/style.min.css" />
</head>

<body>
    <header class="lyear-header text-center" style="background-image:url(/static/index/images/left-bg.jpg);">
        <div class="lyear-header-container">
            <div class="lyear-mask"></div>
            <h1 class="lyear-blogger pt-lg-4 mb-0"><a href="<?php echo url('/'); ?>"><?php echo htmlentities($middle['system']['webname']); ?></a></h1>
            <nav class="navbar navbar-expand-lg">
                <a class="navbar-toggler" data-toggle="collapse" data-target="#navigation" aria-controls="navigation"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <div class="lyear-hamburger">
                        <div class="hamburger-inner"></div>
                    </div>
                </a>

                <div id="navigation" class="collapse navbar-collapse flex-column">
                    <div class="profile-section pt-3 pt-lg-0">
                        <img class="profile-image mb-3 rounded-circle mx-auto" src="/static/index/images/lyear.png" width="120"
                            height="120" alt="笔下光年">
                        <div class="lyear-sentence mb-3"><?php echo htmlentities($middle['system']['personality']); ?>
                        </div>
                        <hr>
                    </div>

                    <ul class="navbar-nav flex-column text-center">
                        <li class="nav-item active">
                            <a class="nav-link" href="<?php echo url('/'); ?>">首页</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('/index/links'); ?>">友链</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('/index/about'); ?>">关于</a>
                        </li>
                    </ul>

                    <div class="my-2 my-md-3">
                        <form class="lyear-search-form form-inline justify-content-center pt-3" action="" method="post">
                            <input type="text" id="semail" name="art_con" class="form-control mr-md-1"
                                placeholder="搜索关键词" />
                        </form>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <div class="lyear-wrapper">
        <section class="mt-5 pb-5">
            <div class="container">


<div class="row">
    <!-- 文章阅读 -->
    <div class="col-xl-8">
        <article class="lyear-arc">
            <div class="arc-header">
                <h2 class="arc-title text-center"><a href="#"><?php echo htmlentities($data['article']['title']); ?></a></h2>
                <ul class="arc-meta">
                    <li><i class="mdi mdi-calendar"></i> <?php echo htmlentities(date("Y/m/d H:i:s",!is_numeric($data['article']['create_time'])? strtotime($data['article']['create_time']) : $data['article']['create_time'])); ?></li>
                    <li><i class="mdi mdi-comment-multiple-outline"></i> <a href="#"><?php echo htmlentities($data['comment_count']); ?> 评论</a></li>
                </ul>
            </div>

            <div class="lyear-arc-detail">

                <?php echo htmlspecialchars_decode($data['article']['content']); ?>

                <div class="mt-5 lyear-comment-title">
                    <h5><span>评论 (<?php echo htmlentities($data['comment_count']); ?>)</span></h5>
                </div>

                <ul class="media-list list-unstyled lyear-comment">
                    <?php if(is_array($data['comment']) || $data['comment'] instanceof \think\Collection || $data['comment'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['comment'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$comm): $mod = ($i % 2 );++$i;?>
                    <li id="comment-1">
                        <div class="media">
                            <img class="d-flex mr-3 rounded-circle" src="/static/index/images/author.jpg" alt="博客">
                            <div class="media-body">
                                <h4 class="media-heading"><a href="#!"><?php echo htmlentities($comm['name']); ?></a></h4>
                                <p class="text-muted post-date"><?php echo htmlentities($comm['create_time']); ?></p>
                                <p><?php echo htmlentities($comm['content']); ?></p>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>

                <div id="respond" class="comment-respond">
                    <div class="mt-2">
                        <h5><span>说点什么吧...</span> <small class="cancel-comment-reply"
                                onclick="cancelReply()">(取消回复)</small></h5>
                    </div>

                    <form action="#" method="post" id="comment" class="mt-4 lyear-comment-form">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input id="author" class="form-control" placeholder="昵称*" name="name" type="text"
                                        required="" />
                                    <input type="text" class="form-control" name="article_id" value="<?php echo htmlentities($data['id']); ?>" hidden
                                        id="formGroupExampleInput" placeholder="请输入邮箱">
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input id="email" class="form-control" placeholder="邮箱*" name="mail" type="text"
                                        required="" />
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <textarea id="comment" class="form-control" rows="5" placeholder="想说的内容"
                                        name="content" required=""></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group text-center">
                                    <button name="submit" onclick="comments()" type="button" id="submit"
                                        class="btn btn-primary">发表评论</button>
                                    <input type='hidden' name='comment_arc_id' value='1' id='comment_arc_id' />
                                    <input type='hidden' name='comment_parent' id='comment_parent' value='0' />
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

            </div>

        </article>
    </div>
    <!-- 内容 end -->



    <!--
 * @Author       : Lucifer
 * @Date         : 2022-11-22 19:20:17
 * @LastEditTime : 2022-12-01 19:12:25
 * @FilePath     : \blog\app\index\view\public\footer.html
-->

<!-- 侧边栏 -->
<div class="col-xl-4">
    <div class="lyear-sidebar">

        <!-- 归档 -->
        <aside class="widget">
            <div class="widget-title">归档文章</div>
            <ul>
                <?php if(is_array($middle['area']) || $middle['area'] instanceof \think\Collection || $middle['area'] instanceof \think\Paginator): $i = 0; $__LIST__ = $middle['area'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$area): $mod = ($i % 2 );++$i;?>
                <li><a href="<?php echo url('./?area='); ?><?php echo htmlentities($area['id']); ?>"><?php echo htmlentities($area['name']); ?></a></li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </aside>

        <!-- 标签 -->
        <aside class="widget widget-tag-cloud">
            <div class="widget-title">快捷标签</div>
            <div class="tag-cloud">
                <a href="#" class="badge badge-primary">首页</a>
                <a href="#" class="badge badge-danger">分享</a>
                <a href="#" class="badge badge-light">收藏</a>
            </div>
        </aside>
    </div>
</div>
<!-- 侧边栏 end -->
</div>

</div>
<!-- end container -->
</section>
</div>
<script type="text/javascript" src="/static/index/js/jquery.min.js"></script>
<script type="text/javascript" src="/static/index/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="/static/index/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/index/js/main.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-notify.min.js"></script>
<script type="text/javascript" src="/static/admin/js/app.min.js"></script>
<script>
    //
</script>
</body>

</html>

    <script>
        function comments() {
            $.ajax({
                type: "POSt",
                url: '<?php echo url("comment"); ?>',
                data: $("#comment").serialize(),
                async: false,
                error: function (request) {
                    alert("error");
                },
                success: function (data) {
                    if (data.code == 200) {
                        window.setTimeout(function () {
                            window.location.reload();
                        }, 2000)
                        showNotify(data.msg, 'success');
                    } else {
                        showNotify(data.msg, 'danger');
                    }
                }
            });
        }
    </script>