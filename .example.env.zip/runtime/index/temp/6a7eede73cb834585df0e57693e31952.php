<?php /*a:2:{s:43:"E:\Web\blog\app\index\view\links\index.html";i:1669528012;s:45:"E:\Web\blog\app\index\view\public\header.html";i:1669528487;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-19 14:58:44
 * @LastEditTime : 2022-11-27 13:46:30
 * @FilePath     : \blog\app\index\view\links\index.html
-->
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-22 19:20:12
 * @LastEditTime : 2022-11-27 13:54:00
 * @FilePath     : \blog\app\index\view\public\header.html
-->

<!DOCTYPE HTML>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo htmlentities($middle['system']['webname']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="yinqi" />
    <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/materialdesignicons.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/style.min.css" />
</head>

<body>
    <header class="lyear-header text-center" style="background-image:url(/static/index/images/left-bg.jpg);">
        <div class="lyear-header-container">
            <div class="lyear-mask"></div>
            <h1 class="lyear-blogger pt-lg-4 mb-0"><a href="<?php echo url('/'); ?>"><?php echo htmlentities($middle['system']['webname']); ?></a></h1>
            <nav class="navbar navbar-expand-lg">
                <a class="navbar-toggler" data-toggle="collapse" data-target="#navigation" aria-controls="navigation"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <div class="lyear-hamburger">
                        <div class="hamburger-inner"></div>
                    </div>
                </a>

                <div id="navigation" class="collapse navbar-collapse flex-column">
                    <div class="profile-section pt-3 pt-lg-0">
                        <img class="profile-image mb-3 rounded-circle mx-auto" src="/static/index/images/lyear.png" width="120"
                            height="120" alt="笔下光年">
                        <div class="lyear-sentence mb-3"><?php echo htmlentities($middle['system']['personality']); ?>
                        </div>
                        <hr>
                    </div>

                    <ul class="navbar-nav flex-column text-center">
                        <li class="nav-item active">
                            <a class="nav-link" href="<?php echo url('/'); ?>">首页</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('/index/links'); ?>">友链</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('/index/about'); ?>">关于</a>
                        </li>
                    </ul>

                    <div class="my-2 my-md-3">
                        <form class="lyear-search-form form-inline justify-content-center pt-3" action="" method="post">
                            <input type="text" id="semail" name="art_con" class="form-control mr-md-1"
                                placeholder="搜索关键词" />
                        </form>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <div class="lyear-wrapper">
        <section class="mt-5 pb-5">
            <div class="container">



<div class="row">
    <!-- 文章列表 -->
    <div class="col-12">
        <article class="lyear-arc">
            <div class="lyear-arc-detail">
                <h5 class="text-center mt-0 mb-3 pb-3">友情链接</h5>

                <div class="alert alert-info" role="alert"> <a href="<?php echo url('create'); ?>">我也想添加友链耶</a> ~</div>
            </div>
        </article>
    </div>
    <!-- 内容 end -->

    <?php if(is_array($data['links']) || $data['links'] instanceof \think\Collection || $data['links'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['links'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$link): $mod = ($i % 2 );++$i;?>
    <div class="col-md-3">
        <div class="alert alert-<?php echo htmlentities($link['color']); ?>" role="alert"><a target="_blank" href="<?php echo htmlentities($link['url']); ?>"> <?php echo htmlentities($link['name']); ?></a></div>
    </div>
    <?php endforeach; endif; else: echo "" ;endif; ?>

</div>

</div>
<!-- end container -->
</section>
</div>
<script type="text/javascript" src="/static/index/js/jquery.min.js"></script>
<script type="text/javascript" src="/static/index/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="/static/index/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/index/js/main.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-notify.min.js"></script>
<script type="text/javascript" src="/static/admin/js/app.min.js"></script>
</body>

</html>