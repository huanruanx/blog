<?php /*a:1:{s:51:"E:\Web\blog\app\index\view\template\test\index.html";i:1669347868;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-25 08:11:18
 * @LastEditTime : 2022-11-25 11:44:28
 * @FilePath     : \blog\app\index\view\template\test\index.html
-->
<div><a href="" id="time"></a></div>
<?php echo htmlentities($data['op']); ?>
<script src="/static/public/js/main.js"></script>