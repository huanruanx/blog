<?php /*a:3:{s:44:"E:\Web\blog\app\index\view\index\index2.html";i:1669454856;s:43:"E:\Web\blog\app\index\view\public\head.html";i:1669434107;s:43:"E:\Web\blog\app\index\view\public\foot.html";i:1669334449;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-22 19:20:44
 * @LastEditTime : 2022-11-26 17:27:36
 * @FilePath     : \blog\app\index\view\index\index2.html
-->
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-22 19:20:12
 * @LastEditTime : 2022-11-26 11:41:41
 * @FilePath     : \blog\app\index\view\public\head.html
-->

<!DOCTYPE HTML>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo htmlentities($middle['system']['webname']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="yinqi" />
    <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/materialdesignicons.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/style.min.css" />
</head>

<body>
    <header class="lyear-header text-center" style="background-image:url(/static/index/images/left-bg.jpg);">
        <div class="lyear-header-container">
            <div class="lyear-mask"></div>
            <h1 class="lyear-blogger pt-lg-4 mb-0"><a href="<?php echo url('/'); ?>"><?php echo htmlentities($middle['system']['webname']); ?></a></h1>
            <nav class="navbar navbar-expand-lg">
                <a class="navbar-toggler" data-toggle="collapse" data-target="#navigation" aria-controls="navigation"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <div class="lyear-hamburger">
                        <div class="hamburger-inner"></div>
                    </div>
                </a>

                <div id="navigation" class="collapse navbar-collapse flex-column">
                    <div class="profile-section pt-3 pt-lg-0">
                        <img class="profile-image mb-3 rounded-circle mx-auto" src="/static/index/images/lyear.png" width="120"
                            height="120" alt="笔下光年">
                        <div class="lyear-sentence mb-3">必须记住我们学习的时间是有限的。时间有限，不只由于人生短促，更由于人事纷繁。我们就应力求把我们所有的时间用去做最有益的事情。
                        </div>
                        <hr>
                    </div>

                    <ul class="navbar-nav flex-column text-center">
                        <li class="nav-item active">
                            <a class="nav-link" href="<?php echo url('/'); ?>">首页</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('./area'); ?>">分类</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('./links2'); ?>">友链</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('./about'); ?>">关于我</a>
                        </li>
                    </ul>

                    <div class="my-2 my-md-3">
                        <form class="lyear-search-form form-inline justify-content-center pt-3">
                            <input type="email" id="semail" name="semail1" class="form-control mr-md-1"
                                placeholder="搜索关键词" />
                        </form>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <div class="lyear-wrapper">
        <section class="mt-5 pb-5">
            <div class="container">
<div class="row">
    <!-- 文章列表 -->
    <div class="col-xl-8">

        <?php if(is_array($data['article']) || $data['article'] instanceof \think\Collection || $data['article'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['article'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$art): $mod = ($i % 2 );++$i;?>
        <article class="lyear-arc">
            <div class="arc-header">
                <h2 class="arc-title"><a href="<?php echo url('dispaly/?id='); ?><?php echo htmlentities($art['id']); ?>"><?php echo htmlentities($art['title']); ?></a></h2>
                <ul class="arc-meta">
                    <li><i class="mdi mdi-calendar"></i> <?php echo htmlentities($art['create_time']); ?></li>
                    <li><i class="mdi mdi-tag-text-outline"></i> <a href="#">蔚来汽车</a>, <a href="#">财报</a></li>
                    <li><i class="mdi mdi-comment-multiple-outline"></i> <a href="#"><?php echo htmlentities($art['visit']); ?></a></li>
                </ul>
            </div>
            <div class="arc-synopsis">
                <div class="alert alert-primary" role="alert"><?php echo htmlentities($art['outline']); ?></div>
            </div>
            <div class="arc-preview text-center">
                <a href="#"><img src="<?php echo htmlentities($art['outline_img']); ?>" alt="" class="img-fluid rounded"></a>
            </div>
        </article>
        <?php endforeach; endif; else: echo "" ;endif; ?>

        <!-- 分页 -->
        <div class="row">
            <div class="col-lg-12">
                <?php echo $data['page']; ?>
            </div>
        </div>
        <!-- 分页 end -->
    </div>
    <!-- 内容 end -->
    <!--
 * @Author       : Lucifer
 * @Date         : 2022-11-22 19:20:17
 * @LastEditTime : 2022-11-25 08:00:20
 * @FilePath     : \blog\app\index\view\public\foot.html
-->

<!-- 侧边栏 -->
<div class="col-xl-4">
    <div class="lyear-sidebar">
        <!-- 热门文章 -->
        <aside class="widget widget-hot-posts">
            <div class="widget-title">热门文章</div>
            <ul>
                <?php if(is_array($middle['hot']) || $middle['hot'] instanceof \think\Collection || $middle['hot'] instanceof \think\Paginator): $i = 0; $__LIST__ = $middle['hot'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$hot): $mod = ($i % 2 );++$i;?>
                <li>
                    <a href=""><?php echo htmlentities($hot['title']); ?></a> <span>{}</span>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </aside>

        <!-- 归档 -->
        <aside class="widget">
            <div class="widget-title">归档</div>
            <ul>
                <?php if(is_array($middle['area']) || $middle['area'] instanceof \think\Collection || $middle['area'] instanceof \think\Paginator): $i = 0; $__LIST__ = $middle['area'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$area): $mod = ($i % 2 );++$i;?>
                <li><a href="<?php echo url('./area/?id='); ?><?php echo htmlentities($area['id']); ?>"><?php echo htmlentities($area['name']); ?></a></li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </aside>

        <!-- 标签 -->
        <aside class="widget widget-tag-cloud">
            <div class="widget-title">标签</div>
            <div class="tag-cloud">
                <a href="#" class="badge badge-light">php</a>
                <a href="#" class="badge badge-primary">苹果</a>
                <a href="#" class="badge badge-danger">比特币</a>
                <a href="#" class="badge badge-light">linux</a>
                <a href="#" class="badge badge-light">前端</a>
                <a href="#" class="badge badge-light">vue</a>
            </div>
        </aside>
    </div>
</div>
<!-- 侧边栏 end -->
</div>

</div>
<!-- end container -->
</section>
</div>
<script type="text/javascript" src="/static/index/js/jquery.min.js"></script>
<script type="text/javascript" src="/static/index/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="/static/index/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/index/js/main.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-notify.min.js"></script>
<script type="text/javascript" src="/static/admin/js/app.min.js"></script>
</body>

</html>