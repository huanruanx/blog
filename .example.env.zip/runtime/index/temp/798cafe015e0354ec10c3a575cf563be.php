<?php /*a:2:{s:44:"E:\Web\blog\app\index\view\links\create.html";i:1669528330;s:45:"E:\Web\blog\app\index\view\public\header.html";i:1669468521;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-19 15:19:01
 * @LastEditTime : 2022-11-27 13:51:20
 * @FilePath     : \blog\app\index\view\links\create.html
-->
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-22 19:20:12
 * @LastEditTime : 2022-11-26 21:14:56
 * @FilePath     : \blog\app\index\view\public\header.html
-->

<!DOCTYPE HTML>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo htmlentities($middle['system']['webname']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="yinqi" />
    <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/materialdesignicons.min.css" />
    <link rel="stylesheet" type="text/css" href="/static/index/css/style.min.css" />
</head>

<body>
    <header class="lyear-header text-center" style="background-image:url(/static/index/images/left-bg.jpg);">
        <div class="lyear-header-container">
            <div class="lyear-mask"></div>
            <h1 class="lyear-blogger pt-lg-4 mb-0"><a href="<?php echo url('/'); ?>"><?php echo htmlentities($middle['system']['webname']); ?></a></h1>
            <nav class="navbar navbar-expand-lg">
                <a class="navbar-toggler" data-toggle="collapse" data-target="#navigation" aria-controls="navigation"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <div class="lyear-hamburger">
                        <div class="hamburger-inner"></div>
                    </div>
                </a>

                <div id="navigation" class="collapse navbar-collapse flex-column">
                    <div class="profile-section pt-3 pt-lg-0">
                        <img class="profile-image mb-3 rounded-circle mx-auto" src="/static/index/images/lyear.png" width="120"
                            height="120" alt="笔下光年">
                        <div class="lyear-sentence mb-3"><?php echo htmlentities($middle['system']['personality']); ?>
                        </div>
                        <hr>
                    </div>

                    <ul class="navbar-nav flex-column text-center">
                        <li class="nav-item active">
                            <a class="nav-link" href="<?php echo url('/'); ?>">首页</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('/index/area'); ?>">分类</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('/index/links'); ?>">友链</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('/index/about'); ?>">关于</a>
                        </li>
                    </ul>

                    <div class="my-2 my-md-3">
                        <form class="lyear-search-form form-inline justify-content-center pt-3">
                            <input type="email" id="semail" name="semail1" class="form-control mr-md-1"
                                placeholder="搜索关键词" />
                        </form>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <div class="lyear-wrapper">
        <section class="mt-5 pb-5">
            <div class="container">
<div class="row">
    <div class="col-md-12">
        <div class="alert alert-info text-body" role="alert">
            添加友链时，请贵站先将我站添加友链，灰黑产不支持，感谢您的配合！
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">

                <form action="#!" id="links" method="post" class="row">
                    <div class="form-group col-md-6">
                        <label for="title">标题</label>
                        <input type="text" class="form-control" id="title" name="name" value="" placeholder="请输入标题" />
                    </div>
                    <div class="form-group col-md-6">
                        <label class="col-xs-12" for="example-select">颜色</label>
                        <select class="form-control" id="example-select" name="color" size="1">
                            <option value="success">绿色</option>
                            <option value="danger">红色</option>
                            <option value="warning">黄色</option>
                            <option value="info">蓝色</option>
                        </select>
                    </div>
                    <div class="form-group col-md-12">
                        <label for="seo_keywords">链接</label>
                        <input type="text" class="form-control" id="seo_keywords" name="url" value=""
                            placeholder="需要添加http或https" />
                    </div>
                    <div class="form-group col-md-12">
                        <label for="seo_description">描述</label>
                        <textarea class="form-control" id="seo_description" name="briefly" rows="5" value=""
                            placeholder="描述一下该站点以及在十个字以内哦"></textarea>
                    </div>
                    <div class="form-group col-md-12 text-center">
                        <button type="button" id="sub" onclick="save()" class="btn btn-primary ajax-post"
                            target-form="add-form">提 交</button>
                        <button type="button" class="btn btn-default"
                            onclick="javascript:history.back(-1);return false;">返 回</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</div>

</div>
<!-- end container -->
</section>
</div>
<script type="text/javascript" src="/static/index/js/jquery.min.js"></script>
<script type="text/javascript" src="/static/index/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="/static/index/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/index/js/main.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-notify.min.js"></script>
<script type="text/javascript" src="/static/admin/js/app.min.js"></script>
</body>

</html>

<script>
    function save() {
        $.ajax({
            type: "POST",
            url: "<?php echo url('save'); ?>",
            data: $("#links").serialize(),
            async: false,
            error: function (request) {
                alert("error");
            },
            success: function (data) {
                if (data.code == 200) {
                    showNotify(data.msg, "success");
                } else {
                    showNotify(data.msg, 'danger');
                }
            }
        });
    }
</script>