<?php /*a:3:{s:45:"E:\Web\blog\app\index\view\message\index.html";i:1668856408;s:45:"E:\Web\blog\app\index\view\public\header.html";i:1668860449;s:45:"E:\Web\blog\app\index\view\public\footer.html";i:1668834863;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-19 17:23:33
 * @LastEditTime : 2022-11-19 19:12:39
 * @FilePath     : \blog\app\index\view\message\index.html
-->
<!DOCTYPE html>
<html lang="zh">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="keywords" content="个人博客,苏小林,blog">
  <meta name="description" content="Su Blog">
  <meta name="author" content="yinq">
  <title>Su - Blog</title>
  <link rel="shortcut icon" type="image/x-icon" href="/static/admin/images/favicon.ico">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-touch-fullscreen" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="default">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/materialdesignicons.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/animate.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/js/bootstrap-table/bootstrap-table.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/style.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/style.css">
</head>

<body>
  <!--页面loading-->
  <div id="lyear-preloader" class="loading">
    <div class="ctn-preloader">
      <div class="round_spinner">
        <div class="spinner"></div>
        <img src="/static/admin/images/loading-logo.png" alt="">
      </div>
    </div>
  </div>
  <!--页面loading end-->
  <div class="lyear-layout-web">
    <div class="lyear-layout-container">
      <!--左侧导航-->
      <aside class="lyear-layout-sidebar">

        <!-- logo -->
        <div id="logo" class="sidebar-header">
          <a href="<?php echo url('/'); ?>"><img src="/static/admin/images/logo-sidebar.png" title="LightYear"
              alt="LightYear" /></a>
        </div>
        <div class="lyear-layout-sidebar-info lyear-scroll">

          <nav class="sidebar-main">
            <ul class="nav-drawer">
              <li class="nav-item active"> <a href="<?php echo url('/'); ?>"><i class="mdi mdi-home"></i> <span>博客首页</span></a>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-home-variant"></i> <span>博客留言</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/index/message'); ?>">评论列表</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-cryengine"></i> <span>友情链接</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/index/links'); ?>">友情列表</a> </li>
                </ul>
              </li>
            </ul>
          </nav>

          <div class="sidebar-footer">
            <p class="copyright">Copyright &copy; 2019. <a href="<?php echo htmlentities($data['system']['weburl']); ?>" target="_blank"><?php echo htmlentities($data['system']['copyright']); ?></a> All rights
              reserved.</p>
          </div>
        </div>

      </aside>
      <!--End 左侧导航-->

      <!--头部信息-->
      <header class="lyear-layout-header">

        <nav class="navbar">

          <div class="navbar-left">
            <div class="lyear-aside-toggler">
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
            </div>
          </div>


          <ul class="navbar-right d-flex align-items-center">
            <!--切换主题配色-->
            <li class="dropdown dropdown-skin">
              <span data-toggle="dropdown" class="icon-item"><i class="mdi mdi-palette"></i></span>
              <ul class="dropdown-menu dropdown-menu-right" data-stopPropagation="true">
                <li class="drop-title">
                  <p>主题</p>
                </li>
                <li class="drop-skin-li clearfix">
                  <span class="inverse">
                    <input type="radio" name="site_theme" value="default" id="site_theme_1" checked>
                    <label for="site_theme_1"></label>
                  </span>
                  <span>
                    <input type="radio" name="site_theme" value="dark" id="site_theme_2">
                    <label for="site_theme_2"></label>
                  </span>
                  <span>
                    <input type="radio" name="site_theme" value="translucent" id="site_theme_3">
                    <label for="site_theme_3"></label>
                  </span>
                </li>
              </ul>
            </li>
            <!--切换主题配色-->
            <li class="dropdown dropdown-profile">
              <a href="javascript:void(0)" data-toggle="dropdown" class="dropdown-toggle">
                <img class="img-avatar img-avatar-48 m-r-10" src="/static/admin/images/users/avatar.jpg"
                  alt="su" />
                <span><?php echo htmlentities($data['system']['webname']); ?></span>
              </a>
              <ul class="dropdown-menu dropdown-menu-right">
                <li>
                  <a class="dropdown-item" href="<?php echo htmlentities($data['system']['contact_url']); ?>" target="_blank"><i class="mdi mdi-lock-outline"></i> 联系博主</a>
                </li>
                <li>
                  <a class="dropdown-item" href="javascript:void(0)"><i class="mdi mdi-delete"></i> 清空缓存</a>
                </li>
              </ul>
            </li>
          </ul>

        </nav>

      </header>
      <!--End 头部信息-->

      <!--页面主要内容-->
      <main class="lyear-layout-content">

        <div class="container-fluid p-t-15">

<div class="row">
    <?php if(is_array($data['message']) || $data['message'] instanceof \think\Collection || $data['message'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['message'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$comm): $mod = ($i % 2 );++$i;?>
    <div class="col-md-3">
        <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <img src="http://q2.qlogo.cn/headimg_dl?dst_uin=<?php echo htmlentities($comm['qq']); ?>&spec=100" style="width: 30px;" class="rounded mr-2" alt="...">
                <strong class="mr-auto"><?php echo htmlentities($comm['name']); ?></strong>
                <small class="text-muted"><?php echo htmlentities($comm['create_time']); ?></small>
            </div>
            <div class="toast-body">
                <?php echo htmlentities($comm['content']); ?>
                <hr>
                <?php echo htmlentities($comm['qq']); ?>
            </div>
        </div>
    </div>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</div>


<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-13 13:58:44
 * @LastEditTime : 2022-11-19 13:13:31
 * @FilePath     : \blog\app\index\view\public\footer.html
-->

</div>

</main>
<!--End 页面主要内容-->
</div>
</div>

<script type="text/javascript" src="/static/admin/js/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/js/popper.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/admin/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery.cookie.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery-confirm/jquery-confirm.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-table/bootstrap-table.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-table/locale/bootstrap-table-zh-CN.min.js"></script>
<script type="text/javascript" src="/static/admin/js/main.min.js"></script>
<script type="text/javascript" src="/static/admin/js/Chart.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-notify.min.js"></script>
<script type="text/javascript" src="/static/admin/js/app.min.js"></script>


</body>

</html>

<script>
    $(".toast").toast({ autohide: false }).toast("show");
</script>