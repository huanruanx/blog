<?php /*a:1:{s:42:"E:\Web\blog\app\index\view\index\test.html";i:1669120556;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-22 20:23:55
 * @LastEditTime : 2022-11-22 20:34:59
 * @FilePath     : \blog\app\index\view\index\test.html
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ok): $mod = ($i % 2 );++$i;?>
        <div>a:</div> 
    <?php endforeach; endif; else: echo "" ;endif; ?>
</body>
</html>