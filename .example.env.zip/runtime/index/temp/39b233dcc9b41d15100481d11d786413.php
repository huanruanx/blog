<?php /*a:3:{s:45:"E:\Web\blog\app\index\view\index\dispaly.html";i:1668933820;s:45:"E:\Web\blog\app\index\view\public\header.html";i:1668860449;s:45:"E:\Web\blog\app\index\view\public\footer.html";i:1668834863;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-18 10:02:55
 * @LastEditTime : 2022-11-20 16:43:37
 * @FilePath     : \blog\app\index\view\index\dispaly.html
-->
<!DOCTYPE html>
<html lang="zh">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="keywords" content="个人博客,苏小林,blog">
  <meta name="description" content="Su Blog">
  <meta name="author" content="yinq">
  <title>Su - Blog</title>
  <link rel="shortcut icon" type="image/x-icon" href="/static/admin/images/favicon.ico">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-touch-fullscreen" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="default">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/materialdesignicons.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/animate.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/js/bootstrap-table/bootstrap-table.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/style.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/style.css">
</head>

<body>
  <!--页面loading-->
  <div id="lyear-preloader" class="loading">
    <div class="ctn-preloader">
      <div class="round_spinner">
        <div class="spinner"></div>
        <img src="/static/admin/images/loading-logo.png" alt="">
      </div>
    </div>
  </div>
  <!--页面loading end-->
  <div class="lyear-layout-web">
    <div class="lyear-layout-container">
      <!--左侧导航-->
      <aside class="lyear-layout-sidebar">

        <!-- logo -->
        <div id="logo" class="sidebar-header">
          <a href="<?php echo url('/'); ?>"><img src="/static/admin/images/logo-sidebar.png" title="LightYear"
              alt="LightYear" /></a>
        </div>
        <div class="lyear-layout-sidebar-info lyear-scroll">

          <nav class="sidebar-main">
            <ul class="nav-drawer">
              <li class="nav-item active"> <a href="<?php echo url('/'); ?>"><i class="mdi mdi-home"></i> <span>博客首页</span></a>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-home-variant"></i> <span>博客留言</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/index/message'); ?>">评论列表</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-cryengine"></i> <span>友情链接</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/index/links'); ?>">友情列表</a> </li>
                </ul>
              </li>
            </ul>
          </nav>

          <div class="sidebar-footer">
            <p class="copyright">Copyright &copy; 2019. <a href="<?php echo htmlentities($data['system']['weburl']); ?>" target="_blank"><?php echo htmlentities($data['system']['copyright']); ?></a> All rights
              reserved.</p>
          </div>
        </div>

      </aside>
      <!--End 左侧导航-->

      <!--头部信息-->
      <header class="lyear-layout-header">

        <nav class="navbar">

          <div class="navbar-left">
            <div class="lyear-aside-toggler">
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
            </div>
          </div>


          <ul class="navbar-right d-flex align-items-center">
            <!--切换主题配色-->
            <li class="dropdown dropdown-skin">
              <span data-toggle="dropdown" class="icon-item"><i class="mdi mdi-palette"></i></span>
              <ul class="dropdown-menu dropdown-menu-right" data-stopPropagation="true">
                <li class="drop-title">
                  <p>主题</p>
                </li>
                <li class="drop-skin-li clearfix">
                  <span class="inverse">
                    <input type="radio" name="site_theme" value="default" id="site_theme_1" checked>
                    <label for="site_theme_1"></label>
                  </span>
                  <span>
                    <input type="radio" name="site_theme" value="dark" id="site_theme_2">
                    <label for="site_theme_2"></label>
                  </span>
                  <span>
                    <input type="radio" name="site_theme" value="translucent" id="site_theme_3">
                    <label for="site_theme_3"></label>
                  </span>
                </li>
              </ul>
            </li>
            <!--切换主题配色-->
            <li class="dropdown dropdown-profile">
              <a href="javascript:void(0)" data-toggle="dropdown" class="dropdown-toggle">
                <img class="img-avatar img-avatar-48 m-r-10" src="/static/admin/images/users/avatar.jpg"
                  alt="su" />
                <span><?php echo htmlentities($data['system']['webname']); ?></span>
              </a>
              <ul class="dropdown-menu dropdown-menu-right">
                <li>
                  <a class="dropdown-item" href="<?php echo htmlentities($data['system']['contact_url']); ?>" target="_blank"><i class="mdi mdi-lock-outline"></i> 联系博主</a>
                </li>
                <li>
                  <a class="dropdown-item" href="javascript:void(0)"><i class="mdi mdi-delete"></i> 清空缓存</a>
                </li>
              </ul>
            </li>
          </ul>

        </nav>

      </header>
      <!--End 头部信息-->

      <!--页面主要内容-->
      <main class="lyear-layout-content">

        <div class="container-fluid p-t-15">

<div class="row">
    <div class="col-md-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo url('/index'); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Library</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header text-center">
                <div class="card-title"><?php echo htmlentities($data['article']['title']); ?></div>
            </div>

            <div class="card-body">
                <div class="alert alert-primary" role="alert"><?php echo htmlentities($data['article']['outline']); ?></div>
                <?php echo htmlspecialchars_decode($data['article']['content']); ?>
                <div class="alert alert-primary" role="alert">
                    <a href=""><span class="mdi mdi-qqchat mdi-24px text-body"></span></a>
                    <a href=""><span class="mdi mdi-wechat mdi-24px text-body"></span></a>
                    <a href=""><span class="mdi mdi-comment mdi-24px text-body"></span></a>
                    <a href="javascript:void(0);"><span class="mdi mdi-link-variant mdi-24px text-body"></span></a>

                    <a href="javascript:void(0);" style="margin-left: 30px;font-size: 18px;"><span
                            class="mdi mdi-heart mdi-24px text-body"> <?php echo htmlentities($data['article']['visit'] + 1); ?></span></a>
                    <div>
                        <span class="badge badge-purple"><?php echo htmlentities($data['article']['label']); ?></span>
                    </div>
                    <div class="text-right"><?php echo htmlentities(date("Y/m/d H:i:s",!is_numeric($data['article']['create_time'])? strtotime($data['article']['create_time']) : $data['article']['create_time'])); ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <div class="card-title">评论区</div>
            </div>
            <div class="card-body">

                <form id="comment">
                    <div class="form-group">
                        <label for="formGroupExampleInput">邮箱</label>
                        <input type="text" class="form-control" name="mail" id="formGroupExampleInput"
                            placeholder="请输入邮箱">
                        <input type="text" class="form-control" name="article_id" value="<?php echo htmlentities($data['id']); ?>" hidden
                            id="formGroupExampleInput" placeholder="请输入邮箱">
                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput2">昵称</label>
                        <input type="text" class="form-control" name="name" id="formGroupExampleInput2"
                            placeholder="请输入昵称">
                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput2">评论内容</label>
                        <input type="text" class="form-control" name="content" id="formGroupExampleInput2"
                            placeholder="请输入内容">
                    </div>
                    <div class="text-center">
                        <button type="button" onclick="comments()" class="btn btn-primary"> 提 交 </button>
                    </div>

                </form>
                <hr class="text-info">
                <?php if(is_array($data['comment']) || $data['comment'] instanceof \think\Collection || $data['comment'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['comment'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$comm): $mod = ($i % 2 );++$i;?>
                <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="toast-header">
                        <!-- <img src="..." class="" alt="..."> -->
                        <span class="mdi mdi-comment text-body rounded mr-2"></span>
                        <strong class="mr-auto"><?php echo htmlentities($comm['name']); ?></strong>
                        <small><?php echo htmlentities($comm['create_time']); ?></small>
                    </div>
                    <div class="toast-body">
                        <?php echo htmlentities($comm['content']); ?>
                    </div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
    </div>

</div>

<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-13 13:58:44
 * @LastEditTime : 2022-11-19 13:13:31
 * @FilePath     : \blog\app\index\view\public\footer.html
-->

</div>

</main>
<!--End 页面主要内容-->
</div>
</div>

<script type="text/javascript" src="/static/admin/js/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/js/popper.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/admin/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery.cookie.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery-confirm/jquery-confirm.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-table/bootstrap-table.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-table/locale/bootstrap-table-zh-CN.min.js"></script>
<script type="text/javascript" src="/static/admin/js/main.min.js"></script>
<script type="text/javascript" src="/static/admin/js/Chart.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-notify.min.js"></script>
<script type="text/javascript" src="/static/admin/js/app.min.js"></script>


</body>

</html>

<script>
    // 消息弹窗
    $(".toast").toast({ autohide: false }).toast("show");
    function comments() {
        $.ajax({
            type: "POSt",
            url: '<?php echo url("comment"); ?>',
            data: $("#comment").serialize(),
            async: false,
            error: function (request) {
                alert("error");
            },
            success: function (data) {
                if (data.code == 200) {
                    showNotify(data.msg, 'success');
                } else {
                    showNotify(data.msg, 'danger');
                }
            }
        });
    }
</script>