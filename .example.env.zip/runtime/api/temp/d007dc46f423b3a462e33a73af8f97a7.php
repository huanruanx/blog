<?php /*a:1:{s:41:"E:\Web\blog\app\api\view\index\index.html";i:1669967501;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-12-02 15:45:56
 * @LastEditTime : 2022-12-02 15:51:36
 * @FilePath     : \blog\app\api\view\index\index.html
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Api</title>
</head>
<body>
    
</body>
</html>