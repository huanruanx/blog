<?php /*a:3:{s:45:"E:\Web\blog\app\admin\view\article\index.html";i:1669293504;s:45:"E:\Web\blog\app\admin\view\public\header.html";i:1669467218;s:45:"E:\Web\blog\app\admin\view\public\footer.html";i:1669467287;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-18 11:40:31
 * @LastEditTime : 2022-11-24 20:37:53
 * @FilePath     : \blog\app\admin\view\article\index.html
-->
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-13 15:06:43
 * @LastEditTime : 2022-11-13 16:49:30
 * @FilePath     : \personal\app\admin\view\visit\index.html
-->
<!DOCTYPE html>
<html lang="zh">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="keywords" content="LightYear,LightYearAdmin,光年,后台模板,博客系统,光年HTML模板">
  <meta name="description" content="个人主页后台">
  <meta name="author" content="yinq">
  <title>Su - Blog Sonsole</title>
  <link rel="shortcut icon" type="image/x-icon" href="/static/admin/images/favicon.ico">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-touch-fullscreen" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="default">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/materialdesignicons.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/animate.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/js/bootstrap-table/bootstrap-table.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/js/jquery-tagsinput/jquery.tagsinput.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/style.min.css">
</head>

<body>
  <!--页面loading-->
  <div id="lyear-preloader" class="loading">
    <div class="ctn-preloader">
      <div class="round_spinner">
        <div class="spinner"></div>
        <img src="/static/admin/images/loading-logo.png" alt="">
      </div>
    </div>
  </div>
  <!--页面loading end-->
  <div class="lyear-layout-web">
    <div class="lyear-layout-container">
      <!--左侧导航-->
      <aside class="lyear-layout-sidebar">

        <!-- logo -->
        <div id="logo" class="sidebar-header">
          <a href="<?php echo url('/admin'); ?>"><img src="/static/admin/images/logo-sidebar.png" title="LightYear"
              alt="LightYear" /></a>
        </div>
        <div class="lyear-layout-sidebar-info lyear-scroll">

          <nav class="sidebar-main">
            <ul class="nav-drawer">
              <li class="nav-item active"> <a href="<?php echo url('/admin/'); ?>"><i class="mdi mdi-home"></i> <span>后台首页</span></a>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-file-document-box-multiple"></i> <span>文章管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/article'); ?>">文章列表</a> </li>
                  <li> <a href="<?php echo url('/admin/article/create'); ?>">文章添加</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-hockey-puck"></i> <span>文章分类</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/area'); ?>">分类列表</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-comment-text-multiple"></i> <span>评论管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/comment/'); ?>">评论列表</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-link"></i> <span>友情管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/links'); ?>">友情管理</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-cryengine"></i> <span>访问管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/visit'); ?>">访问记录</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-delete-outline"></i> <span>回收数据</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/retrieve'); ?>">文章</a> </li>
                  <li> <a href="<?php echo url('/admin/retrieve/comment'); ?>">评论</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-tools"></i> <span>系统管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/system'); ?>">网站设置</a> </li>
                  <li> <a href="<?php echo url('/admin/system/pass'); ?>">密码修改</a> </li>
                </ul>
              </li>
            </ul>
          </nav>

          <div class="sidebar-footer">
            <p class="copyright">Copyright &copy; 2019. <a href="http://yyyyyyy.ml" target="_blank">苏小林</a> All rights
              reserved.</p>
          </div>
        </div>

      </aside>
      <!--End 左侧导航-->

      <!--头部信息-->
      <header class="lyear-layout-header">

        <nav class="navbar">

          <div class="navbar-left">
            <div class="lyear-aside-toggler">
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
            </div>
          </div>

          <ul class="navbar-right d-flex align-items-center">
            <!--切换主题配色-->
            <li class="dropdown dropdown-skin">
              <span data-toggle="dropdown" class="icon-item"><i class="mdi mdi-palette"></i></span>
              <ul class="dropdown-menu dropdown-menu-right" data-stopPropagation="true">
                <li class="drop-title">
                  <p>主题</p>
                </li>
                <li class="drop-skin-li clearfix">
                  <span class="inverse">
                    <input type="radio" name="site_theme" value="default" id="site_theme_1" checked>
                    <label for="site_theme_1"></label>
                  </span>
                  <span>
                    <input type="radio" name="site_theme" value="dark" id="site_theme_2">
                    <label for="site_theme_2"></label>
                  </span>
                </li>
              </ul>
            </li>
            <!--切换主题配色-->
            <li class="dropdown dropdown-profile">
              <a href="javascript:void(0)" data-toggle="dropdown" class="dropdown-toggle">
                <img class="img-avatar img-avatar-48 m-r-10" src="/static/admin/images/users/avatar.jpg"
                  alt="su" />
                <span>苏小林</span>
              </a>
              <ul class="dropdown-menu dropdown-menu-right">
                <li>
                  <a class="dropdown-item" href="../../admin/system"><i class="mdi mdi-lock-outline"></i> 修改密码</a>
                </li>
                <li>
                  <a class="dropdown-item" href="javascript:void(0)"><i class="mdi mdi-delete"></i> 清空缓存</a>
                </li>
                <li class="dropdown-divider"></li>
                <li>
                  <a class="dropdown-item" href="../../admin/login/logout"><i class="mdi mdi-logout-variant"></i>
                    退出登录</a>
                </li>
              </ul>
            </li>
          </ul>

        </nav>

      </header>
      <!--End 头部信息-->

      <!--页面主要内容-->
      <main class="lyear-layout-content">

        <div class="container-fluid p-t-15">

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <header class="card-header">
                <div class="card-title">文章列表</div>
            </header>
            <div class="card-body">
                <div class="alert alert-success" role="alert">
                    文章删除后首页将不再显示，但是系统采用得是软删除，可以重新恢复文章。
                </div>
                <div id="toolbar" class="toolbar-btn-action">
                    
                </div>
                <table id="tb_departments"></table>
            </div>
        </div>
    </div>
</div>



<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-13 13:58:44
 * @LastEditTime : 2022-11-26 20:54:12
 * @FilePath     : \blog\app\admin\view\public\footer.html
-->

</div>

</main>
<!--End 页面主要内容-->
</div>
</div>

<script type="text/javascript" src="/static/admin/js/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/js/popper.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/admin/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery.cookie.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery-confirm/jquery-confirm.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-table/bootstrap-table.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-table/locale/bootstrap-table-zh-CN.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery-tagsinput/jquery.tagsinput.min.js"></script>
<script type="text/javascript" src="/static/admin/js/main.min.js"></script>
<script type="text/javascript" src="/static/admin/js/Chart.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-notify.min.js"></script>
<script type="text/javascript" src="/static/admin/js/app.min.js"></script>


</body>

</html>
<script type="text/javascript">
    $('#tb_departments').bootstrapTable({
        classes: 'table table-bordered table-hover table-striped',
        url: '../../admin/article/display',
        method: 'get',
        dataType: 'json',        // 因为本示例中是跨域的调用,所以涉及到ajax都采用jsonp,
        uniqueId: 'id',
        idField: 'id',             // 每行的唯一标识字段
        toolbar: '#toolbar',       // 工具按钮容器
        clickToSelect: true,     // 是否启用点击选中行
        showColumns: true,         // 是否显示所有的列
        showRefresh: true,         // 是否显示刷新按钮

        showToggle: true,        // 是否显示详细视图和列表视图的切换按钮(clickToSelect同时设置为true时点击会报错)

        pagination: true,                    // 是否显示分页
        sortOrder: "desc",                    // 排序方式
        queryParams: function (params) {
            var temp = {
                limit: params.limit,         // 每页数据量
                offset: params.offset,       // sql语句起始索引
                page: (params.offset / params.limit) + 1,
                sort: params.sort,           // 排序的列名
                sortOrder: params.order      // 排序方式'asc' 'desc'
            };
            return temp;
        },                                   // 传递参数
        sidePagination: "client",            // 分页方式：client客户端分页，server服务端分页
        pageNumber: 1,                       // 初始化加载第一页，默认第一页
        pageSize: 10,                        // 每页的记录行数
        pageList: [10, 25, 50, 100],         // 可供选择的每页的行数
        search: true,                      // 是否显示表格搜索，此搜索是客户端搜索

        //showExport: true,        // 是否显示导出按钮, 导出功能需要导出插件支持(tableexport.min.js)
        //exportDataType: "basic", // 导出数据类型, 'basic':当前页, 'all':所有数据, 'selected':选中的数据

        columns: [{
            field: 'example',
            checkbox: true    // 是否显示复选框
        }, {
            field: 'id',
            title: 'ID',
            sortable: true    // 是否排序
        }, {
            field: 'title',
            title: '标题'
        }, {
            field: 'outline',
            title: '概括'
        }, {
            field: 'area_id',
            title: '分类'
        }, {
            field: 'create_time',
            title: '时间',
        }, {
            field: 'operate',
            title: '操作',
            formatter: btnGroup,  // 自定义方法
            events: {
                'click .del-btn': function (event, value, row, index) {
                    delUser(row.id);
                }
            }
        }],
        onLoadSuccess: function (data) {
            $("[data-toggle='tooltip']").tooltip();
        }
    });

    // 操作按钮
    function btnGroup() {
        let html =
            '<a href="#!" class="btn btn-xs btn-default del-btn" title="删除" data-toggle="tooltip"><i class="mdi mdi-window-close"></i></a>';
        return html;
    }

    // 操作方法 - 删除
    function delUser(id) {
        del(id);
        // alert('信息删除成功' + id);
    }

    function del(id) {
        $.post("<?php echo url('delete'); ?>", {
            id: id,
        }, function (res) {
            if (res.code == 200) {
                showNotify('添加成功~', 'success');
            } else {
                showNotify(res.msg, 'danger');
            }
        }, 'json')
    }
</script>
