<?php /*a:3:{s:46:"E:\Web\blog\app\admin\view\article\create.html";i:1669433633;s:45:"E:\Web\blog\app\admin\view\public\header.html";i:1669466870;s:45:"E:\Web\blog\app\admin\view\public\footer.html";i:1668914589;}*/ ?>
<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-18 11:40:39
 * @LastEditTime : 2022-11-26 11:33:33
 * @FilePath     : \blog\app\admin\view\article\create.html
-->
<!DOCTYPE html>
<html lang="zh">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="keywords" content="LightYear,LightYearAdmin,光年,后台模板,博客系统,光年HTML模板">
  <meta name="description" content="个人主页后台">
  <meta name="author" content="yinq">
  <title>Su - Blog Sonsole</title>
  <link rel="shortcut icon" type="image/x-icon" href="/static/admin/images/favicon.ico">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-touch-fullscreen" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="default">
  <link rel="stylesheet" type="text/css" href="../../static/admin/css/materialdesignicons.min.css">
  <link rel="stylesheet" type="text/css" href="../../static/admin/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../../static/admin/css/animate.min.css">
  <link rel="stylesheet" type="text/css" href="../../static/admin/js/bootstrap-table/bootstrap-table.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/js/jquery-tagsinput/jquery.tagsinput.min.css">
  <link rel="stylesheet" type="text/css" href="../../static/admin/css/style.min.css">
</head>

<body>
  <!--页面loading-->
  <div id="lyear-preloader" class="loading">
    <div class="ctn-preloader">
      <div class="round_spinner">
        <div class="spinner"></div>
        <img src="/static/admin/images/loading-logo.png" alt="">
      </div>
    </div>
  </div>
  <!--页面loading end-->
  <div class="lyear-layout-web">
    <div class="lyear-layout-container">
      <!--左侧导航-->
      <aside class="lyear-layout-sidebar">

        <!-- logo -->
        <div id="logo" class="sidebar-header">
          <a href="<?php echo url('/admin'); ?>"><img src="/static/admin/images/logo-sidebar.png" title="LightYear"
              alt="LightYear" /></a>
        </div>
        <div class="lyear-layout-sidebar-info lyear-scroll">

          <nav class="sidebar-main">
            <ul class="nav-drawer">
              <li class="nav-item active"> <a href="<?php echo url('/admin/'); ?>"><i class="mdi mdi-home"></i> <span>后台首页</span></a>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-file-document-box-multiple"></i> <span>文章管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/article'); ?>">文章列表</a> </li>
                  <li> <a href="<?php echo url('/admin/article/create'); ?>">文章添加</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-hockey-puck"></i> <span>文章分类</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/area'); ?>">分类列表</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-comment-text-multiple"></i> <span>评论管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/comment/'); ?>">评论列表</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-link"></i> <span>友情管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/links'); ?>">友情管理</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-cryengine"></i> <span>访问管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/visit'); ?>">访问记录</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-delete-outline"></i> <span>回收数据</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/retrieve'); ?>">文章</a> </li>
                  <li> <a href="<?php echo url('/admin/retrieve/comment'); ?>">评论</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-tools"></i> <span>系统管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/system'); ?>">网站设置</a> </li>
                  <li> <a href="<?php echo url('/admin/system/pass'); ?>">密码修改</a> </li>
                </ul>
              </li>
            </ul>
          </nav>

          <div class="sidebar-footer">
            <p class="copyright">Copyright &copy; 2019. <a href="http://yyyyyyy.ml" target="_blank">苏小林</a> All rights
              reserved.</p>
          </div>
        </div>

      </aside>
      <!--End 左侧导航-->

      <!--头部信息-->
      <header class="lyear-layout-header">

        <nav class="navbar">

          <div class="navbar-left">
            <div class="lyear-aside-toggler">
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
            </div>
          </div>

          <ul class="navbar-right d-flex align-items-center">
            <!--切换主题配色-->
            <li class="dropdown dropdown-skin">
              <span data-toggle="dropdown" class="icon-item"><i class="mdi mdi-palette"></i></span>
              <ul class="dropdown-menu dropdown-menu-right" data-stopPropagation="true">
                <li class="drop-title">
                  <p>主题</p>
                </li>
                <li class="drop-skin-li clearfix">
                  <span class="inverse">
                    <input type="radio" name="site_theme" value="default" id="site_theme_1" checked>
                    <label for="site_theme_1"></label>
                  </span>
                  <span>
                    <input type="radio" name="site_theme" value="dark" id="site_theme_2">
                    <label for="site_theme_2"></label>
                  </span>
                </li>
              </ul>
            </li>
            <!--切换主题配色-->
            <li class="dropdown dropdown-profile">
              <a href="javascript:void(0)" data-toggle="dropdown" class="dropdown-toggle">
                <img class="img-avatar img-avatar-48 m-r-10" src="../../static/admin/images/users/avatar.jpg"
                  alt="su" />
                <span>苏小林</span>
              </a>
              <ul class="dropdown-menu dropdown-menu-right">
                <li>
                  <a class="dropdown-item" href="../../admin/system"><i class="mdi mdi-lock-outline"></i> 修改密码</a>
                </li>
                <li>
                  <a class="dropdown-item" href="javascript:void(0)"><i class="mdi mdi-delete"></i> 清空缓存</a>
                </li>
                <li class="dropdown-divider"></li>
                <li>
                  <a class="dropdown-item" href="../../admin/login/logout"><i class="mdi mdi-logout-variant"></i>
                    退出登录</a>
                </li>
              </ul>
            </li>
          </ul>

        </nav>

      </header>
      <!--End 头部信息-->

      <!--页面主要内容-->
      <main class="lyear-layout-content">

        <div class="container-fluid p-t-15">
<script src="../../static/admin/tinymce/tinymce.min.js"></script>
<script>
    tinymce.init({
        language: 'zh_CN', //调用放在langs文件夹内的语言包
        selector: '#seo_description',
        images_upload_url: '<?php echo url("upload"); ?>',
        toolbar1: 'undo redo styleselect bold italic link image alignleft aligncenter alignright emoticons searchreplace',
        // toolbar: 'image',
        plugins: ['quickbars', 'link', 'table', 'image'],
        setup: function (editor) {
            editor.on('change', function () {
                editor.save();
            })
        },
        convert_urls: false
    });
</script>
<link rel="stylesheet" href="/static/admin/css/cropper.min.css">
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">

                <form action="#!" method="post" class="row" id="article">
                    <div class="form-group col-md-12">
                        <label for="title">文章标题</label>
                        <input type="text" class="form-control" id="title" name="title" value="" placeholder="请输入标题" />
                    </div>
                    <div class="form-group col-md-12">
                        <label for="seo_keywords">文章概述</label>
                        <input type="text" class="form-control" id="seo_keywords" name="outline" value=""
                            placeholder="文章概述" />
                    </div>

                    <div class="form-group col-md-12">
                        <label for="pic_url">概览图片</label>
                        <div class="input-group">
                            <input type="text" class="form-control image-src" name="picurl" placeholder="点击左侧上传即可，此处无需手动" value="" />
                            <div class="input-group-btn">
                                <button class="btn btn-default trigger-btn" type="button">上传图片</button>
                            </div>
                        </div>
                    </div>


                    <div class="form-group col-md-6">
                        <label for="upload_image_ext">文章标签</label>
                        <select class="form-control" name="area" id="exampleFormControlSelect1">
                            <?php if(is_array($data['area']) || $data['area'] instanceof \think\Collection || $data['area'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['area'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$area): $mod = ($i % 2 );++$i;?>
                            <option value="<?php echo htmlentities($area['id']); ?>"><?php echo htmlentities($area['name']); ?></option>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="upload_image_ext">文章分类</label>
                        <input class="js-tags-input form-control" type="text" id="upload_image_ext" name="label"
                            value="" placeholder="请输入标签后回车">
                        <small class="help-block">多个标签采用英文逗号隔开</small>
                    </div>

                    <div class="form-group col-md-12">
                        <label for="seo_description">文章内容</label>
                        <textarea class="form-control" id="seo_description" name="content" rows="5" value=""
                            placeholder="请输入你的文章内容吧~~"></textarea>
                    </div>
                    <div class="form-group col-md-12 text-center">
                        <button type="button" class="btn btn-primary" id="submit" onclick="sub()"
                            target-form="add-form">提 交</button>
                        <button type="button" class="btn btn-default"
                            onclick="javascript:history.back(-1);return false;">返 回</button>
                    </div>
                </form>

                <!--图片裁剪START-->
                <div class="modal fade" id="image-modal" aria-hidden="true" aria-labelledby="image-modal-label"
                    role="dialog" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title h6" id="image-modal-label">上传图片</h4>
                                <button class="close" data-dismiss="modal" type="button">&times;</button>
                            </div>
                            <div class="modal-body">
                                <div class="image-body">
                                    <div class="image-upload m-b-15">
                                        <button class="btn btn-primary" type="button"
                                            onclick="$('input[id=imageInput]').click();">请选择图片</button>

                                        <span class="image-name">
                                            <div class="alert alert-success image-name" role="alert"></div>
                                        </span>
                                        <input type="file" class="image-input hide" id="imageInput" name="file"
                                            accept=".jpg,.jpeg,.png,.gif,.bmp,.tiff" hidden>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-9 m-b-15">
                                            <div class="image-wrapper"></div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="image-previews clearfix">
                                                <div class="image-preview preview-lg"></div>
                                                <div class="image-preview preview-md"></div>
                                                <div class="image-preview preview-sm"></div>
                                                <div class="image-preview preview-xs"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 image-btns">
                                            <button class="btn btn-primary mdi mdi-rotate-left" data-method="rotate"
                                                data-option="-45" type="button" title="向左旋转-45度"></button>
                                            <button class="btn btn-primary mdi mdi-rotate-right" data-method="rotate"
                                                data-option="45" type="button" title="向右旋转45度"></button>
                                            <button type="button" class="btn btn-primary mdi mdi-magnify-plus-outline"
                                                data-method="zoom" data-option="0.1" title="放大图片"></button>
                                            <button type="button" class="btn btn-primary mdi mdi-magnify-minus-outline"
                                                data-method="zoom" data-option="-0.1" title="缩小图片"></button>
                                            <button type="button" class="btn btn-primary mdi mdi-cached"
                                                data-method="reset" title="重置图片"></button>
                                        </div>
                                        <div class="col-md-5 image-btns toggles-btns">
                                            <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                                <label class="btn btn-primary active">
                                                    <input type="radio" name="aspectRatio" id="aspectRatio1"
                                                        value="1.7777777777777777" checked>
                                                    <span>16:9</span>
                                                </label>
                                                <label class="btn btn-primary">
                                                    <input type="radio" name="aspectRatio" id="aspectRatio2"
                                                        value="1.3333333333333333">
                                                    <span>4:3</span>
                                                </label>
                                                <label class="btn btn-primary">
                                                    <input type="radio" name="aspectRatio" id="aspectRatio3" value="1">
                                                    <span>1:1</span>
                                                </label>
                                                <label class="btn btn-primary">
                                                    <input type="radio" name="aspectRatio" id="aspectRatio3"
                                                        value="0.6666666666666666">
                                                    <span>2:3</span>
                                                </label>
                                                <label class="btn btn-primary">
                                                    <input type="radio" name="aspectRatio" id="aspectRatio3"
                                                        value="NaN">
                                                    <span>自适应</span>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <button class="btn btn-primary btn-block upload-btn mdi mdi-content-save"
                                                type="submit">保存修改</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--图片裁剪END-->


            </div>
        </div>
    </div>
</div>

<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-13 13:58:44
 * @LastEditTime : 2022-11-20 11:23:09
 * @FilePath     : \blog\app\admin\view\public\footer.html
-->

</div>

</main>
<!--End 页面主要内容-->
</div>
</div>

<script type="text/javascript" src="../../static/admin/js/jquery.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/popper.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/jquery.cookie.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/jquery-confirm/jquery-confirm.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/bootstrap-table/bootstrap-table.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/bootstrap-table/locale/bootstrap-table-zh-CN.min.js"></script>
<script src="/static/admin/js/jquery-tagsinput/jquery.tagsinput.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/main.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/Chart.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/bootstrap-notify.min.js"></script>
<script type="text/javascript" src="../../static/admin/js/app.min.js"></script>


</body>

</html>
<script src="/static/admin/js/cropper.min.js"></script>
<script src="/static/admin/js/jquery.lyear.loading.js"></script>
<script src="/static/admin/js/lyear-loading.js"></script>
<script src="/static/admin/js/lightyear.js"></script>

<script>
    function cropImage() {
        this.$triggerBtn = $('.trigger-btn');                            // 上传按钮
        this.$imageText = this.$triggerBtn.parent().prev('.image-src'); // 图片地址输入框
        this.$imageModal = $('#image-modal');                            // 弹出框
        this.$imageName = this.$imageModal.find('.image-name')          // 图片名称
        this.$imageInput = this.$imageModal.find('.image-input');        // file上传文件
        this.$imageUpload = this.$imageModal.find('.image-upload');       // file所在元素
        this.$imageBtns = this.$imageModal.find('.image-btns');         // 图片调整按钮(旋转、放大等)
        this.$imageWrapper = this.$imageModal.find('.image-wrapper');      // 图片处理区域
        this.$imagePreview = this.$imageModal.find('.image-preview');      // 图片裁剪预览区域
        this.$uploadBtn = this.$imageModal.find('.upload-btn');         // 上传按钮
        this.$togglesBtns = this.$imageModal.find('.toggles-btns');       // 比例切换按钮
        this.URL = window.URL || window.webkitURL;
        this.$options = {
            aspectRatio: 16 / 9,
            preview: '.image-preview'
        };                                                                 // 配置
        this.init();
    }
    cropImage.prototype = {
        constructor: cropImage,
        init: function () {
            this.initModal();
            this.addListener();
        },
        initModal: function () {
            this.$imageModal.modal({
                show: false
            });

            if (!URL) {
                this.$imageInput.prop('disabled', true);
            }
        },
        addListener: function () {
            // 绑定事件
            this.$triggerBtn.on('click', $.proxy(this.click, this));
            this.$imageInput.on('change', $.proxy(this.change, this));
            this.$togglesBtns.on('change', $.proxy(this.choose, this));
            this.$uploadBtn.on('click', $.proxy(this.ajaxUpload, this));
            this.$imageBtns.on('click', $.proxy(this.rotate, this));
        },
        click: function (e) {
            // 点击上传按钮
            this.$imageText = $(e.target).parent().prev('.image-src');
            this.$imageModal.modal('show');
            this.initPreview();
        },
        initPreview: function () {
            this.active = false;
            this.$imageInput.val('');
            this.$imageName.text('');
            this.$imageWrapper.empty();
            // 如果已有图片地址，初始化图片预览区域
            this.$imagePreview.empty();
            var url = this.$imageText.val();
            (url.length > 0) && this.$imagePreview.html('<img src="' + url + '">');
        },
        change: function () {
            // 选择图片
            var files, file;
            files = this.$imageInput.prop('files');

            if (files && files.length > 0) {
                file = files[0];
                if (this.isImageFile(file)) {
                    this.$imageType = file.type;
                    this.$imageName.text(file.name);
                    if (this.imageUrl) {
                        this.URL.revokeObjectURL(this.imageUrl);
                    }
                    this.imageUrl = this.URL.createObjectURL(file);
                    this.startCropper();
                }
            }
        },
        startCropper: function () {
            // 选择图片后初始化
            if (this.active) {
                this.$image.cropper('replace', this.imageUrl, true);
            } else {
                this.$image = $('<img src="' + this.imageUrl + '">');
                this.$imageWrapper.empty().html(this.$image);
                this.$image.cropper('destroy').cropper(this.$options);

                this.active = true;
            }
        },
        isImageFile: function (file) {
            // 判断是否图片格式
            if (file.type) {
                return /^image\/\w+$/.test(file.type);
            } else {
                return /\.(jpg|jpeg|png|gif|bmp|tiff)$/.test(file);
            }
        },
        choose: function (e) {
            var $this = $(e.target);
            var name = $this.attr('name');

            if (!this.active) {
                return;
            }

            this.$options[name] = $this.val();
            this.$image.cropper('destroy').cropper(this.$options);
        },
        rotate: function (e) {
            // 调整图片操作
            var data;
            if (this.active) {
                data = $(e.target).data();
                if (data.method) {
                    this.$image.cropper(data.method, data.option);
                }
            }
        },
        stopCropper: function () {
            // 裁剪上传完成后重置
            if (this.active) {
                this.$image.cropper('destroy');
                this.$image.remove();
                this.$imageModal.modal('hide');
                this.$imageInput.val('');
                this.$imageName.text('');
                this.$togglesBtns.find('#aspectRatio1').attr('checked', true);
                this.active = false;
            }
        },
        ajaxUpload: function () {
            var cas = this.$image.cropper('getCroppedCanvas'),
                base64Data = cas.toDataURL(this.$imageType),
                _this = this,
                $loading;

            // ajax上传
            $.ajax("<?php echo url('upload_img'); ?>", {
                type: 'post',
                data: {
                    "img": base64Data
                },
                dataType: 'json',
                beforeSend: function () {
                    _this.$uploadBtn.prop('disabled', true);
                    $loading = $('.upload-btn').lyearloading({
                        opacity: 0.2,
                        spinnerSize: 'nm'
                    });
                },
                success: function (data) {
                    if ($.isPlainObject(data) && data.state === 200) {
                        _this.$imageText.val(data.picurl);
                        _this.stopCropper();
                        lightyear.notify(data.message, 'success', 3000);
                    } else {
                        lightyear.notify(data.message, 'danger', 3000);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    console.log(textStatus);
                },
                complete: function () {
                    _this.$uploadBtn.prop('disabled', false);
                    $loading.destroy();
                }
            });
        }
    };
    $(document).ready(function () {
        new cropImage();
    });
</script>

<script>
    function sub() {
        $.ajax({
            type: "POST",
            url: "./save",
            data: $("#article").serialize(),
            async: false,
            error: function (request) {
                alert("error");
            },
            success: function (data) {
                if (data.code == 200) {
                    showNotify('添加成功~', 'success');
                } else {
                    showNotify(data.msg, 'danger');
                }
            }
        });
    }
</script>