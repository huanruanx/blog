<?php /*a:3:{s:43:"E:\Web\blog\app\admin\view\index\index.html";i:1668920908;s:45:"E:\Web\blog\app\admin\view\public\header.html";i:1669467218;s:45:"E:\Web\blog\app\admin\view\public\footer.html";i:1669467287;}*/ ?>
<!DOCTYPE html>
<html lang="zh">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="keywords" content="LightYear,LightYearAdmin,光年,后台模板,博客系统,光年HTML模板">
  <meta name="description" content="个人主页后台">
  <meta name="author" content="yinq">
  <title>Su - Blog Sonsole</title>
  <link rel="shortcut icon" type="image/x-icon" href="/static/admin/images/favicon.ico">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-touch-fullscreen" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="default">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/materialdesignicons.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/animate.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/js/bootstrap-table/bootstrap-table.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/js/jquery-tagsinput/jquery.tagsinput.min.css">
  <link rel="stylesheet" type="text/css" href="/static/admin/css/style.min.css">
</head>

<body>
  <!--页面loading-->
  <div id="lyear-preloader" class="loading">
    <div class="ctn-preloader">
      <div class="round_spinner">
        <div class="spinner"></div>
        <img src="/static/admin/images/loading-logo.png" alt="">
      </div>
    </div>
  </div>
  <!--页面loading end-->
  <div class="lyear-layout-web">
    <div class="lyear-layout-container">
      <!--左侧导航-->
      <aside class="lyear-layout-sidebar">

        <!-- logo -->
        <div id="logo" class="sidebar-header">
          <a href="<?php echo url('/admin'); ?>"><img src="/static/admin/images/logo-sidebar.png" title="LightYear"
              alt="LightYear" /></a>
        </div>
        <div class="lyear-layout-sidebar-info lyear-scroll">

          <nav class="sidebar-main">
            <ul class="nav-drawer">
              <li class="nav-item active"> <a href="<?php echo url('/admin/'); ?>"><i class="mdi mdi-home"></i> <span>后台首页</span></a>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-file-document-box-multiple"></i> <span>文章管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/article'); ?>">文章列表</a> </li>
                  <li> <a href="<?php echo url('/admin/article/create'); ?>">文章添加</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-hockey-puck"></i> <span>文章分类</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/area'); ?>">分类列表</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-comment-text-multiple"></i> <span>评论管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/comment/'); ?>">评论列表</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-link"></i> <span>友情管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/links'); ?>">友情管理</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-cryengine"></i> <span>访问管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/visit'); ?>">访问记录</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-delete-outline"></i> <span>回收数据</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/retrieve'); ?>">文章</a> </li>
                  <li> <a href="<?php echo url('/admin/retrieve/comment'); ?>">评论</a> </li>
                </ul>
              </li>
              <li class="nav-item nav-item-has-subnav">
                <a href="javascript:void(0)"><i class="mdi mdi-tools"></i> <span>系统管理</span></a>
                <ul class="nav nav-subnav">
                  <li> <a href="<?php echo url('/admin/system'); ?>">网站设置</a> </li>
                  <li> <a href="<?php echo url('/admin/system/pass'); ?>">密码修改</a> </li>
                </ul>
              </li>
            </ul>
          </nav>

          <div class="sidebar-footer">
            <p class="copyright">Copyright &copy; 2019. <a href="http://yyyyyyy.ml" target="_blank">苏小林</a> All rights
              reserved.</p>
          </div>
        </div>

      </aside>
      <!--End 左侧导航-->

      <!--头部信息-->
      <header class="lyear-layout-header">

        <nav class="navbar">

          <div class="navbar-left">
            <div class="lyear-aside-toggler">
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
            </div>
          </div>

          <ul class="navbar-right d-flex align-items-center">
            <!--切换主题配色-->
            <li class="dropdown dropdown-skin">
              <span data-toggle="dropdown" class="icon-item"><i class="mdi mdi-palette"></i></span>
              <ul class="dropdown-menu dropdown-menu-right" data-stopPropagation="true">
                <li class="drop-title">
                  <p>主题</p>
                </li>
                <li class="drop-skin-li clearfix">
                  <span class="inverse">
                    <input type="radio" name="site_theme" value="default" id="site_theme_1" checked>
                    <label for="site_theme_1"></label>
                  </span>
                  <span>
                    <input type="radio" name="site_theme" value="dark" id="site_theme_2">
                    <label for="site_theme_2"></label>
                  </span>
                </li>
              </ul>
            </li>
            <!--切换主题配色-->
            <li class="dropdown dropdown-profile">
              <a href="javascript:void(0)" data-toggle="dropdown" class="dropdown-toggle">
                <img class="img-avatar img-avatar-48 m-r-10" src="/static/admin/images/users/avatar.jpg"
                  alt="su" />
                <span>苏小林</span>
              </a>
              <ul class="dropdown-menu dropdown-menu-right">
                <li>
                  <a class="dropdown-item" href="../../admin/system"><i class="mdi mdi-lock-outline"></i> 修改密码</a>
                </li>
                <li>
                  <a class="dropdown-item" href="javascript:void(0)"><i class="mdi mdi-delete"></i> 清空缓存</a>
                </li>
                <li class="dropdown-divider"></li>
                <li>
                  <a class="dropdown-item" href="../../admin/login/logout"><i class="mdi mdi-logout-variant"></i>
                    退出登录</a>
                </li>
              </ul>
            </li>
          </ul>

        </nav>

      </header>
      <!--End 头部信息-->

      <!--页面主要内容-->
      <main class="lyear-layout-content">

        <div class="container-fluid p-t-15">
<!-- 
重要事情说三遍
重要事情说三遍
重要事情说三遍
不要对本文件进行格式化，一旦格式化导致有些语法错乱导致无法运行等问题的出现 
-->

<link href="http://example.itshubao.com/demo/css/materialdesignicons.min.css" rel="stylesheet">

<div class="row">
    <div class="col-md-6 col-xl-3">
        <div class="card bg-primary text-white">
            <div class="card-body clearfix">
                <div class="flex-box">
                    <span class="img-avatar img-avatar-48 bg-translucent"><i class="mdi mdi-cryengine fs-22"></i></span>
                    <span class="fs-22 lh-22"><?php echo htmlentities($data['visit']); ?></span>
                </div>
                <div class="text-right">文章浏览</div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-xl-3">
        <div class="card bg-danger text-white">
            <div class="card-body clearfix">
                <div class="flex-box">
                    <span class="img-avatar img-avatar-48 bg-translucent"><i
                            class="mdi mdi-file-document-box-multiple fs-22"></i></span>
                    <span class="fs-22 lh-22"><?php echo htmlentities($data['article']); ?></span>
                </div>
                <div class="text-right">文章总数</div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-xl-3">
        <div class="card bg-success text-white">
            <div class="card-body clearfix">
                <div class="flex-box">
                    <span class="img-avatar img-avatar-48 bg-translucent"><i class="mdi mdi-pinterest fs-22"></i></span>
                    <span class="fs-22 lh-22"><?php echo htmlentities($data['comment']); ?></span>
                </div>
                <div class="text-right">评论总数</div>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-xl-3">
        <div class="card bg-purple text-white">
            <div class="card-body clearfix">
                <div class="flex-box">
                    <span class="img-avatar img-avatar-48 bg-translucent"><i
                            class="mdi mdi-comment-outline fs-22"></i></span>
                    <span class="fs-22 lh-22">9</span>
                </div>
                <div class="text-right">留言总数</div>
            </div>
        </div>
    </div>
</div>

<div class="row">

    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <div class="card-title">每周留言</div>
            </div>
            <div class="card-body">
                <canvas class="js-chartjs-bars"></canvas>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <div class="card-title">每周访问</div>
            </div>
            <div class="card-body">
                <canvas class="js-chartjs-lines"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <div class="card-title">系统信息</div>
            </div>
            <div class="card-body">
                <table class="table table-bordered text-center">
                    <tbody>
                        <tr>
                            <td>系统版本</td>
                            <td><?php echo config('su.version'); ?> <a href="http://github.com/suxaiolin/blog" target="_blank">检测更新</a></td>
                        </tr>
                        <tr>
                            <td>UI版本</td>
                            <td><a href="http://lyear.itshubao.com/v4" target="_blank">光年模板[Light Year Admin V4]</a>
                            </td>
                        </tr>
                        <tr>
                            <td>框架版本</td>
                            <td><a href="http://thinkphp.cn" target="_blank">ThinkPHP V6.1.0</a>
                            </td>
                        </tr>
                        <tr>
                            <td>开源地址</td>
                            <td><a href="https://github.com/yiyanyun">GITHUB</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <div class="card-title">最近动态</div>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <tbody>
                        <?php if(is_array($data['dynamic']) || $data['dynamic'] instanceof \think\Collection || $data['dynamic'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['dynamic'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$do): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <th scope="row"><?php echo htmlentities($do['id']); ?></th>
                            <td><?php echo htmlentities($do['name']); ?></td>
                            <td><?php echo htmlentities($do['content']); ?></td>
                            <td><?php echo htmlentities($do['ip']); ?></td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!--
 * @Author       : Lucifer
 * @Date         : 2022-11-13 13:58:44
 * @LastEditTime : 2022-11-26 20:54:12
 * @FilePath     : \blog\app\admin\view\public\footer.html
-->

</div>

</main>
<!--End 页面主要内容-->
</div>
</div>

<script type="text/javascript" src="/static/admin/js/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/js/popper.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/static/admin/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery.cookie.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery-confirm/jquery-confirm.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-table/bootstrap-table.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-table/locale/bootstrap-table-zh-CN.min.js"></script>
<script type="text/javascript" src="/static/admin/js/jquery-tagsinput/jquery.tagsinput.min.js"></script>
<script type="text/javascript" src="/static/admin/js/main.min.js"></script>
<script type="text/javascript" src="/static/admin/js/Chart.min.js"></script>
<script type="text/javascript" src="/static/admin/js/bootstrap-notify.min.js"></script>
<script type="text/javascript" src="/static/admin/js/app.min.js"></script>


</body>

</html>
<script>
    $(document).ready(function (e) {
        var $dashChartBarsCnt = jQuery('.js-chartjs-bars')[0].getContext('2d'),
            $dashChartLinesCnt = jQuery('.js-chartjs-lines')[0].getContext('2d');

        var $dashChartBarsData = {
            labels: <?php echo htmlentities($data['data_time']); ?>,
            datasets: [
                {
                    label: '评论统计',
                    borderWidth: 1,
                    borderColor: 'rgba(0, 0, 0, 0)',
                    backgroundColor: 'rgba(51, 202, 185, 0.5)',
                    hoverBackgroundColor: "rgba(51, 202, 185, 0.7)",
                    hoverBorderColor: "rgba(0, 0, 0, 0)",
                    data: <?php echo htmlentities($data['msg_total']); ?>
                }
            ]
        };
        var $dashChartLinesData = {
            labels: <?php echo htmlentities($data['data_time']); ?>,
            datasets: [
                {
                    label: '首页访问',
                    data: <?php echo htmlentities($data['visit_total']); ?>,
                    borderColor: '#358ed7',
                    backgroundColor: 'rgba(53, 142, 215, 0.175)',
                    borderWidth: 1,
                    fill: false,
                    lineTension: 0.5
                }
            ]
        };

        new Chart($dashChartBarsCnt, {
            type: 'bar',
            data: $dashChartBarsData
        });

        var myLineChart = new Chart($dashChartLinesCnt, {
            type: 'line',
            data: $dashChartLinesData,
        });
    });
</script>

<script>
    function upcheck() {
        $.ajax({
            type: "POST",
            url: "<?php echo url('update'); ?>",
            data: {
                // 此处无需传递参数仅占位左右
            },
            dataType: 'json',
            success: function (data) {
                if (data.code == 200) {
                    showNotify(data.msg, 'success');
                } else {
                    showNotify(data.msg, 'danger');
                }
            }
        });
    }
</script>