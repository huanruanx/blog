<?php 
/*
 * @Author       : Lucifer
 * @Date         : 2022-12-02 11:33:07
 * @LastEditTime : 2022-12-02 14:45:01
 * @FilePath     : \blog\app\api\route\app.php
 */

use think\facade\Route;


Route::any('/:code','index/index');