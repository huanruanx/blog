<?php
/*
 * @Author       : Lucifer
 * @Date         : 2022-11-18 08:48:20
 * @LastEditTime : 2022-11-25 07:27:14
 * @FilePath     : \blog\app\index\middleware.php
 */
// 这是系统自动生成的middleware定义文件
return [
    \app\index\middleware\Middle::class
];
